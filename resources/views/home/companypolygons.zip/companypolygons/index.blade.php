@extends('layouts.appHome')

@push('styles')
<style>
    .small-text {
        font-size: 10px; /* You can set the size as per your needs */
    }
</style>
@endpush
@section('content')
<div class="container">
    <h1>List of Companies</h1>
    
    <!-- Filter Form -->
       <!-- phone mask -->
       <div class="form-group">
                
                  <form method="GET" action="{{ route('allcompaniesdata.index') }}">
                  <div class="input-group">
                                  
                  <!-- /.input group -->
               
   
        <input type="text" class="form-control"  name="company_name" placeholder="Company Name" value="{{ request('company_name') }}">
        <input type="text" class="form-control" name="mineral_name" placeholder="Mineral Name" value="{{ request('mineral_name') }}">
        <input type="text" class="form-control" name="status" placeholder="Status" value="{{ request('status') }}">
        <button class="btn btn-primary" type="submit">Filter</button>
    </form>
 </div>
    <!-- Export Links -->
    <!-- <a href="route('allcompaniesdatapdf') " class="btn btn-primary">Export PDF</a>
    <a href="route('allcompaniesdataexcel') " class="btn btn-primary">Export Excel</a> -->
     <div class="row>
     <div class="col-sm-12">
    <!-- Data Table -->
    <table class="table table-bordered table-sm text-small">
        <thead>
            <tr><th>#</th>
                <th><small><a href="?sort_by=company_name&sort_order={{ request('sort_order') == 'asc' ? 'desc' : 'asc' }}">Company Name</a></small></th>
                <th><small><a href="?sort_by=mineral_name&sort_order={{ request('sort_order') == 'asc' ? 'desc' : 'asc' }}">Mineral Name</a></small></th>
                 <th><small>District</small></th>
                <th><small>Status</small></th>
                <th><small>Granted Date</small></th>
                <th><small>Area</small></th>
                <th><small>Scale</small></th>
                <th><small>Tenure</small></th>
            </tr>
        </thead>
        <tbody>
            @foreach($polygons as $polygon)
            <tr><td>  {{ ($polygons->currentPage() - 1) * $polygons->perPage() + $loop->iteration }}</td>
                <td><small>{{ $polygon->company_name }}</small></td>
                <td><small>{{ $polygon->mineral_name }}</small></td>
                <td><small>{{ $polygon->district }}</small></td>
                <td><small>{{ $polygon->status }}</small></td>
                <td><small>{{ date('d-m-Y', strtotime($polygon->granted_date)) }}</small></td>   
                <td><small>{{ $polygon->area }}</small></td>
                <td><small>{{ $polygon->scale }}</small></td>
                <td><small>{{ $polygon->tanure }}</small></td>
            </tr>
            @endforeach
          
        </tbody>
  
    </table>

    <!-- Pagination -->
    <div class="d-flex justify-content-center">
        {{ $polygons->links('pagination.bootstrap-5') }}
    </div>

    </div>
    </div>
    <!-- /.row -->
   
</div>
@endsection
